// Complete the function in the editor below by returning a RegExp object, re, that matches every integer in some string s.
// Constraints
//     The length of string 8 is >= 3.
//     It's guaranteed that string  contains at least one integer.
// Output Format
//     The function must return a RegExp object that matches every integer in some string s.

const regexVar = () => {
  let re = /\d+/g;
  return re;
};
