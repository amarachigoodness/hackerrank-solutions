const btns = document.querySelector("#btns");
let items = btns.children;
let reorder = (e) => {
  btns.insertBefore(items[3], btns.children[0]);
  btns.insertBefore(items[5], btns.children[9]);
  let savedItem1 = items[5];
  btns.removeChild(items[5]);
  btns.insertBefore(savedItem1, btns.children[3]);
  let savedItem2 = items[5];
  btns.removeChild(items[5]);
  btns.insertBefore(savedItem2, btns.children[4]);
};
items[4].addEventListener("click", reorder);
